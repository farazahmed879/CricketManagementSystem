﻿namespace WebApp.Models
{
    public class EmailTemplate
    {

        public int Id { get; set; }
        public string Name { get; set; }
        public string ClubName { get; set; }
        public string Body { get; set; }
        public string Message { get; set; }
        public string Title { get; set; }
    }
}
